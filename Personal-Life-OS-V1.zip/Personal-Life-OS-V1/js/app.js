const DB_NAME="life-os-v1", DB_VERSION=1;
const state={view:"today",date:new Date(),tasks:[],habits:[],habitLogs:[],workouts:[],journals:[],goals:[],events:[],settings:{}};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const iso=d=>{const x=new Date(d);return new Date(x.getTime()-x.getTimezoneOffset()*60000).toISOString().slice(0,10)};
const parseDate=s=>new Date(s+"T12:00:00");
const fmt=d=>new Intl.DateTimeFormat(undefined,{weekday:"long",month:"long",day:"numeric",year:"numeric"}).format(d);
const shortDate=d=>new Intl.DateTimeFormat(undefined,{month:"short",day:"numeric"}).format(d);
const uid=p=>p+"_"+crypto.randomUUID();
let db;

function openDB(){
 return new Promise((resolve,reject)=>{
  const r=indexedDB.open(DB_NAME,DB_VERSION);
  r.onupgradeneeded=()=>{db=r.result;
   ["tasks","habits","habitLogs","workouts","journals","goals","events","settings"].forEach(s=>{if(!db.objectStoreNames.contains(s))db.createObjectStore(s,{keyPath:"id"})});
  };
  r.onsuccess=()=>{db=r.result;resolve(db)}; r.onerror=()=>reject(r.error);
 });
}
function all(store){return new Promise((res,rej)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
function put(store,obj){return new Promise((res,rej)=>{const r=db.transaction(store,"readwrite").objectStore(store).put(obj);r.onsuccess=()=>res(obj);r.onerror=()=>rej(r.error)})}
function del(store,id){return new Promise((res,rej)=>{const r=db.transaction(store,"readwrite").objectStore(store).delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
async function refresh(){for(const s of ["tasks","habits","habitLogs","workouts","journals","goals","events","settings"])state[s]=await all(s);render()}

function tasksFor(date){return state.tasks.filter(t=>t.date===iso(date))}
function logsFor(date){return state.habitLogs.filter(x=>x.date===iso(date))}
function workoutFor(date){return state.workouts.filter(x=>x.date===iso(date))}
function journalFor(date){return state.journals.find(x=>x.date===iso(date))}
function stats(date){
 const ts=tasksFor(date), done=ts.filter(t=>t.status==="completed").length, moved=ts.filter(t=>t.status==="moved").length, skipped=ts.filter(t=>t.status==="skipped").length, missed=ts.filter(t=>t.status==="missed").length;
 const active=ts.length, score=active?Math.round(done/active*100):0;
 return {ts,done,moved,skipped,missed,active,score};
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function dayName(d){return new Intl.DateTimeFormat(undefined,{weekday:"long"}).format(d)}
function greet(){const h=new Date().getHours();return h<12?"Good morning.":h<18?"Good afternoon.":"Good evening."}

function render(){
 $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===state.view));
 const titles={today:["PERSONAL NOTEBOOK","Today"],tomorrow:["PREPARATION","Tomorrow"],calendar:["MEMORY","Calendar"],insights:["UNDERSTANDING","Insights"],settings:["YOUR NOTEBOOK","Settings"]};
 $("#viewEyebrow").textContent=titles[state.view][0];$("#viewTitle").textContent=titles[state.view][1];
 $("#dateChip").textContent=shortDate(state.date);
 $("#datePrev").style.visibility=["today","tomorrow"].includes(state.view)?"visible":"hidden";
 $("#dateNext").style.visibility=["today","tomorrow"].includes(state.view)?"visible":"hidden";
 const html={today:renderToday,tomorrow:renderTomorrow,calendar:renderCalendar,insights:renderInsights,settings:renderSettings}[state.view]();
 $("#view").innerHTML=`<div class="fade-in">${html}</div>`;
 bindView();
}
function taskHTML(t){
 const cls=t.status==="completed"?"done":"";
 const dot=t.priority==="focus"?"focus":t.priority==="important"?"important":"";
 return `<div class="task ${cls}" data-id="${t.id}">
 <button class="check" data-complete="${t.id}">${t.status==="completed"?"✓":""}</button>
 <span class="priority-dot ${dot}"></span><div class="task-title">${esc(t.title)}</div>
 ${t.time?`<span class="task-meta">${esc(t.time)}</span>`:""}
 <button class="text-btn" data-delete="${t.id}" title="Delete">×</button></div>`;
}
function renderToday(){
 const s=stats(state.date), d=state.date, logs=logsFor(d), habits=state.habits;
 const pct=s.score, j=journalFor(d), ws=workoutFor(d);
 const taskBlock=s.ts.length?s.ts.map(taskHTML).join(""):`<div class="empty">Nothing planned yet. Start with one meaningful task.</div>`;
 return `<div class="hero">
  <div class="hero-card"><p class="greeting">${greet()}</p><div class="context">${fmt(d)} · Your day, your pace.</div>
   <div style="height:22px"></div><div class="eyebrow">TODAY'S FOCUS</div>
   <div style="font:800 22px Manrope;margin-top:7px">${s.active?`${s.done} of ${s.active} complete`:"A clean page awaits."}</div>
   <div style="height:9px"></div><div class="bar"><i style="width:${pct}%"></i></div>
  </div>
  <div class="hero-card progress-card"><div class="ring" style="--p:${pct}"><b>${pct}%</b></div><div class="progress-copy"><b>${s.done} completed</b><span>${s.active-s.done-s.moved-s.skipped} unresolved · ${s.moved} moved · ${s.missed} missed</span><div style="margin-top:12px"><button class="primary" id="reviewDay">Review day</button></div></div></div>
 </div>
 <div class="grid">
  <div class="section"><div class="section-head"><h3>FOCUS & TO DO</h3><button class="text-btn" id="addTaskInline">+ Add</button></div><div class="task-list">${taskBlock}</div></div>
  <div class="section"><div class="section-head"><h3>HABITS</h3><button class="text-btn" id="addHabit">+ Add habit</button></div>
   ${habits.length?habits.map(h=>{const l=logs.find(x=>x.habitId===h.id);return `<div class="habit-row"><div><strong style="font-size:13px">${esc(h.name)}</strong><div class="muted">${h.streak||0} day streak</div></div><button class="mini-check ${l?.done?"done":""}" data-habit="${h.id}">${l?.done?"✓":"○"}</button></div>`}).join(""):`<div class="empty">Add a habit you want to repeat.</div>`}
  </div>
  <div class="section"><div class="section-head"><h3>EXERCISE</h3><button class="text-btn" id="addWorkout">+ Log</button></div>
   ${ws.length?ws.map(w=>`<div class="exercise-row"><div style="flex:1"><strong style="font-size:13px">${esc(w.name)}</strong><div class="muted">${esc(w.detail||"Completed")}</div></div><span style="color:var(--good)">✓</span></div>`).join(""):`<div class="empty">No workout logged today.</div>`}
  </div>
  <div class="section"><div class="section-head"><h3>JOURNAL</h3><button class="text-btn" id="editJournal">${j?"Edit":"Write"}</button></div>
   ${j?`<div style="font-size:13px;line-height:1.65;color:#cbd2dc">${esc(j.text)}</div>`:`<div class="empty">A few honest lines can close the day.</div>`}
  </div>
 </div>`;
}
function renderTomorrow(){
 const d=new Date(state.date);d.setDate(d.getDate()+1); const s=stats(d);
 return `<div class="hero-card" style="margin-bottom:18px"><div class="eyebrow">NEXT DAY</div><h2 style="font:800 26px Manrope;margin:6px 0">${fmt(d)}</h2><p class="muted">Prepare tomorrow without losing what happened today.</p><button class="primary" id="carryOver">Carry unfinished from ${shortDate(state.date)}</button></div>
 <div class="grid"><div class="section full"><div class="section-head"><h3>TOMORROW'S PLAN</h3><button class="text-btn" id="addTomorrow">+ Add task</button></div>${s.ts.length?s.ts.map(taskHTML).join(""):`<div class="empty">Your next page is empty. Add a few intentional things.</div>`}</div></div>`;
}
function renderCalendar(){
 const d=state.date, y=d.getFullYear(),m=d.getMonth(),first=new Date(y,m,1),last=new Date(y,m+1,0), start=first.getDay();
 let cells=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(x=>`<div class="cal-weekday">${x}</div>`).join("");
 for(let i=0;i<start;i++)cells+=`<div></div>`;
 for(let n=1;n<=last.getDate();n++){const day=new Date(y,m,n),s=stats(day),has=s.active||logsFor(day).length||workoutFor(day).length||journalFor(day);let level=s.score>=75?"good":s.score>=40?"mid":s.active?"low":"";cells+=`<button class="cal-day ${iso(day)===iso(new Date())?"today":""}" data-day="${iso(day)}"><span class="cal-num">${n}</span>${has?`<i class="day-dot ${level}"></i><span class="day-pct">${s.score}%</span>`:""}</button>`}
 return `<div class="section"><div class="calendar-head"><button class="ghost" id="calPrev">‹</button><h2>${new Intl.DateTimeFormat(undefined,{month:"long",year:"numeric"}).format(d)}</h2><button class="ghost" id="calNext">›</button></div><div class="cal-grid">${cells}</div></div>`;
}
function renderInsights(){
 const today=new Date(), dates=[];for(let i=0;i<30;i++){const d=new Date(today);d.setDate(d.getDate()-i);dates.push(d)}
 let total=0,done=0,miss=0,moved=0,work=0;
 dates.forEach(d=>{const s=stats(d);total+=s.active;done+=s.done;miss+=s.missed; moved+=s.moved;work+=workoutFor(d).length});
 const rate=total?Math.round(done/total*100):0, activeHabits=state.habits.length;
 const streaks=state.habits.map(h=>({name:h.name,streak:h.streak||0})).sort((a,b)=>b.streak-a.streak);
 return `<div class="hero-card" style="margin-bottom:18px"><div class="eyebrow">LAST 30 DAYS</div><h2 style="font:800 25px Manrope;margin:6px 0">A quiet look at your patterns.</h2><p class="muted">Insights are calculated from your saved notebook history.</p></div>
 <div class="insights"><div class="metric"><b>${rate}%</b><span>Task completion</span></div><div class="metric"><b>${done}</b><span>Tasks completed</span></div><div class="metric"><b>${work}</b><span>Workout entries</span></div><div class="metric"><b>${miss}</b><span>Tasks missed</span></div><div class="metric"><b>${moved}</b><span>Tasks moved</span></div><div class="metric"><b>${activeHabits}</b><span>Active habits</span></div></div>
 <div class="section" style="margin-top:18px"><div class="section-head"><h3>HABIT CONSISTENCY</h3></div>${streaks.length?streaks.map(x=>`<div class="statline"><span>${esc(x.name)}</span><strong>${x.streak} days</strong></div>`).join(""):`<div class="empty">Build a little history first.</div>`}</div>`;
}
function renderSettings(){
 return `<div class="section"><div class="section-head"><h3>NOTEBOOK</h3></div>
 <div class="settings-row"><div><strong>Storage</strong><div class="muted">IndexedDB · device local</div></div><span style="color:var(--good)">● Ready</span></div>
 <div class="settings-row"><div><strong>Export backup</strong><div class="muted">Portable JSON snapshot of your notebook.</div></div><button class="primary" id="exportBtn">Export</button></div>
 <div class="settings-row"><div><strong>Import backup</strong><div class="muted">Restore a previous JSON snapshot.</div></div><button class="ghost" id="importBtn">Import</button></div>
 <div class="settings-row"><div><strong>About V1</strong><div class="muted">Today → Tomorrow → Calendar → Insights</div></div><span class="muted">v1.0</span></div></div>`;
}

function bindView(){
 $$("[data-complete]").forEach(b=>b.onclick=async e=>{const t=state.tasks.find(x=>x.id===b.dataset.complete);if(!t)return;t.status=t.status==="completed"?"planned":"completed";t.completedAt=t.status==="completed"?new Date().toISOString():null;await put("tasks",t);await put("events",{id:uid("evt"),type:t.status==="completed"?"TASK_COMPLETED":"TASK_REOPENED",entityId:t.id,date:iso(state.date),timestamp:new Date().toISOString()});refresh();toast(t.status==="completed"?"Completed ✓":"Reopened")});
 $$("[data-delete]").forEach(b=>b.onclick=async()=>{await del("tasks",b.dataset.delete);toast("Task removed");refresh()});
 $("#addTaskInline")?.addEventListener("click",()=>openTask(iso(state.date)));
 $("#addTomorrow")?.addEventListener("click",()=>{const d=new Date(state.date);d.setDate(d.getDate()+1);openTask(iso(d))});
 $("#addBtn").onclick=()=>openTask(iso(state.view==="tomorrow"?new Date(state.date.getTime()+86400000):state.date));
 $("#reviewDay")?.addEventListener("click",openReview);
 $("#carryOver")?.addEventListener("click",carryOver);
 $("#addHabit")?.addEventListener("click",async()=>{const name=prompt("Habit name");if(name?.trim()){await put("habits",{id:uid("hab"),name:name.trim(),createdAt:new Date().toISOString(),streak:0});refresh()}});
 $$("[data-habit]").forEach(b=>b.onclick=async()=>{const id=b.dataset.habit,date=iso(state.date),old=state.habitLogs.find(x=>x.habitId===id&&x.date===date);if(old){old.done=!old.done;await put("habitLogs",old)}else await put("habitLogs",{id:uid("hlog"),habitId:id,date,done:true});await recalcStreak(id);refresh()});
 $("#addWorkout")?.addEventListener("click",async()=>{const name=prompt("Exercise / workout name");if(name?.trim()){const detail=prompt("Details (e.g. 3 × 15, 2:00)")||"Completed";await put("workouts",{id:uid("work"),date:iso(state.date),name:name.trim(),detail});await put("events",{id:uid("evt"),type:"WORKOUT_LOGGED",entityId:name.trim(),date:iso(state.date),timestamp:new Date().toISOString()});refresh()}});
 $("#editJournal")?.addEventListener("click",async()=>{const old=journalFor(state.date);const text=prompt("Write today's journal entry:",old?.text||"");if(text!==null){if(old){old.text=text;old.updatedAt=new Date().toISOString();await put("journals",old)}else await put("journals",{id:uid("jrnl"),date:iso(state.date),text,createdAt:new Date().toISOString()});refresh()}});
 $$("[data-day]").forEach(b=>b.onclick=()=>{state.date=parseDate(b.dataset.day);state.view="today";render()});
 $("#calPrev")?.addEventListener("click",()=>{state.date=new Date(state.date.getFullYear(),state.date.getMonth()-1,1);render()});
 $("#calNext")?.addEventListener("click",()=>{state.date=new Date(state.date.getFullYear(),state.date.getMonth()+1,1);render()});
 $("#exportBtn")?.addEventListener("click",exportData);$("#importBtn")?.addEventListener("click",importData);
}
async function recalcStreak(id){const h=state.habits.find(x=>x.id===id);if(!h)return;let streak=0,d=new Date();for(let i=0;i<366;i++){const date=iso(d),log=state.habitLogs.find(x=>x.habitId===id&&x.date===date&&x.done);if(!log)break;streak++;d.setDate(d.getDate()-1)}h.streak=streak;await put("habits",h)}
function openTask(date){$("#taskDate").value=date;$("#taskTitle").value="";$("#taskNotes").value="";$("#taskTime").value="";$("#taskDialog").showModal();setTimeout(()=>$("#taskTitle").focus(),50)}
$("#taskForm").addEventListener("submit",async e=>{e.preventDefault();const t={id:uid("task"),title:$("#taskTitle").value.trim(),category:$("#taskCategory").value,priority:$("#taskPriority").value,date:$("#taskDate").value,time:$("#taskTime").value,notes:$("#taskNotes").value,status:"planned",createdAt:new Date().toISOString(),completedAt:null};if(!t.title)return;await put("tasks",t);await put("events",{id:uid("evt"),type:"TASK_CREATED",entityId:t.id,date:t.date,timestamp:new Date().toISOString()});$("#taskDialog").close();toast("Saved ✓");refresh()});
$$("[data-close]").forEach(b=>b.onclick=()=>b.closest("dialog").close());
async function carryOver(){const s=stats(state.date),next=new Date(state.date);next.setDate(next.getDate()+1);const target=iso(next);for(const t of s.ts.filter(x=>x.status==="planned")){t.status="moved";t.movedTo=target;await put("tasks",t);const copy={...t,id:uid("task"),date:target,status:"planned",originalId:t.id,createdAt:new Date().toISOString()};await put("tasks",copy);await put("events",{id:uid("evt"),type:"TASK_MOVED",entityId:t.id,fromDate:iso(state.date),toDate:target,timestamp:new Date().toISOString()})}toast("Unfinished tasks carried forward");refresh()}
function openReview(){const s=stats(state.date), unresolved=s.ts.filter(t=>["planned"].includes(t.status));$("#reviewTitle").textContent=`Close ${dayName(state.date)}`;$("#reviewCopy").textContent=`${s.done} completed · ${unresolved.length} unresolved · ${s.moved} moved. Decide what should happen to the unresolved items.`;$("#reviewItems").innerHTML=unresolved.length?unresolved.map(t=>`<div class="review-item"><strong>${esc(t.title)}</strong><div class="review-options"><button data-review="${t.id}" data-status="moved">Move tomorrow</button><button data-review="${t.id}" data-status="skipped">Skip intentionally</button><button data-review="${t.id}" data-status="missed">Mark missed</button></div></div>`).join(""):`<div class="empty">Everything is resolved. Nice work.</div>`;$("#reviewDialog").showModal();$$("[data-review]").forEach(b=>b.onclick=()=>{$$(`[data-review="${b.dataset.review}"]`).forEach(x=>x.classList.remove("active"));b.classList.add("active");b.parentElement.dataset.choice=b.dataset.status)});$("#reviewSave").onclick=async()=>{for(const box of $$(".review-item")){const id=box.querySelector("[data-review]")?.dataset.review,choice=box.querySelector(".active")?.dataset.status;if(id&&choice){const t=state.tasks.find(x=>x.id===id);t.status=choice;if(choice==="moved"){const next=new Date(state.date);next.setDate(next.getDate()+1);t.movedTo=iso(next);const copy={...t,id:uid("task"),date:t.movedTo,status:"planned",originalId:t.id,createdAt:new Date().toISOString()};await put("tasks",copy)}await put("tasks",t);await put("events",{id:uid("evt"),type:"TASK_"+choice.toUpperCase(),entityId:id,date:iso(state.date),timestamp:new Date().toISOString()})}}$("#reviewDialog").close();toast("Day review saved");refresh()}}

async function exportData(){const data={schemaVersion:1,app:"Life OS",exportedAt:new Date().toISOString(),data:{}};for(const s of ["tasks","habits","habitLogs","workouts","journals","goals","events","settings"])data.data[s]=state[s];const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`LifeOS_Backup_${iso(new Date())}.json`;a.click();URL.revokeObjectURL(a.href);toast("Backup exported")}
function importData(){const input=document.createElement("input");input.type="file";input.accept=".json,application/json";input.onchange=async()=>{const file=input.files[0];if(!file)return;try{const data=JSON.parse(await file.text());if(data.schemaVersion!==1||!data.data)throw Error("Unsupported backup");for(const [s,items] of Object.entries(data.data)){if(!["tasks","habits","habitLogs","workouts","journals","goals","events","settings"].includes(s))continue;for(const item of items)await put(s,item)}toast("Backup restored");refresh()}catch(e){alert("Could not import this backup.")}};input.click()}
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>x.classList.remove("show"),1800)}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>{state.view=b.dataset.view;render()}));
$("#datePrev").onclick=()=>{state.date=new Date(state.date);state.date.setDate(state.date.getDate()-1);render()};
$("#dateNext").onclick=()=>{state.date=new Date(state.date);state.date.setDate(state.date.getDate()+1);render()};
openDB().then(async()=>{await seed();await refresh()}).catch(e=>{console.error(e);alert("Local database could not be opened.")});
async function seed(){if(state.tasks.length)return;const d=iso(new Date());const seeds=[["Study Mathematics","Study","focus"],["Work on project","Project","important"],["Read 20 pages","Personal","normal"],["Organize files","Personal","normal"]];for(const [title,category,priority] of seeds)await put("tasks",{id:uid("task"),title,category,priority,date:d,time:"",notes:"",status:"planned",createdAt:new Date().toISOString(),completedAt:null});await put("habits",{id:uid("hab"),name:"Reading",createdAt:new Date().toISOString(),streak:0});await put("habits",{id:uid("hab"),name:"Exercise",createdAt:new Date().toISOString(),streak:0})}
