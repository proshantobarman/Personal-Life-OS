# Personal Life OS — V1

A local-first personal digital notebook / Life OS.

## V1 pillars

- TODAY — action
- TOMORROW — preparation
- CALENDAR — memory
- INSIGHTS — understanding

## Included

- IndexedDB persistence
- Tasks with category, priority, date, time and notes
- Completed / moved / skipped / missed task states
- Tomorrow carry-over
- Calendar day history
- Habits with daily completion + streak
- Exercise logging
- Daily journal
- Basic 30-day insights
- JSON export/import
- Mobile-first responsive UI
- Local-only core data
- Micro-interactions and touch-friendly controls

## Run

Open `index.html` in a modern browser.

For the best PWA-style future expansion, serve the folder from a local/static web server or GitHub Pages.

## Important

The app is local-first. Export regular JSON backups because browser/device storage is not an absolute archival guarantee.

## Next build

V1.1 / V1.5 should focus on:
- richer daily record snapshots
- proper recurring tasks/habits
- timeline
- undo
- search
- PWA shell
- more advanced exercise history
- stronger migration tests
